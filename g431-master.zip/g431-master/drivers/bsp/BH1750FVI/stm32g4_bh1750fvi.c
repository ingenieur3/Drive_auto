/**
 *******************************************************************************
 * @file	stm32g4_bh1750fvi.c
 * @author	C�cile Lebrun 		&& Luc H�rault --> portage sur g431
 * @date	November 24, 2016 	&& 2024
 * @brief	Module pour utiliser le BH1750FVI
 *******************************************************************************
 * @verbatim
 * Ce pilote permet d'interfacer le capteur de luminosit� BH1750FVI.
 * Ce capteur permet de mesurer la luminosit� ambiante pour ensuite, par exemple, ajuster la luminosit� d'un �cran
 * de smartphone ou encore le r�tro-�clairage d'un clavier.
 *
 * Comment utiliser ce pilote :
 * 		1. L'initialiser (initialiser son bus I2C) avec la fonction BH1750FVI_init.
 * 		2. L'allumer avec la fonction BH1750FVI_powerOn.
 * 		3. Choisir son mode de mesure. Il est possible de choisir entre une mesure en continu ou une mesure en "one-shot".
 * 		   On peut �galement choisir la r�solution du capteur. Les r�solutions disponibles (en lux) sont les suivantes :
 *
 * 		   										Temps de mesure		Resolution
 * 		   			High resolution mode 2			120 ms			0.5 lx
 * 		   			High resolution mode 1			120 ms			1 lx
 * 		   			Low resolution					16 ms			4 lx
 *
 * 		   Le constructeur conseille l'utilisation du high resolution mode 1, celui-ci �tant �galement adapt� � la mesure
 * 		   de la luminosit� dans l'obsurit� (quand la luminosit� est inf�rieure � 10 lx).
 * 		   Cette �tape se fait via l'appel de la fonction BH1750FVI_measureMode en lui passant comme argument le mode souhait�
 * 		   (les diff�rents modes possibles sont list�s dans le fichier bh1750fvi.h).
 *
 * 		 4. Eteindre le capteur. Dans le cas du mode de mesures en continu, il faut l'�teindre � la main � la fin des mesures
 * 		 	en appelant la fonction BH1750FVI_powerDown. Dans le cas d'une mesure en one-shot, l'extinction se fait automatiquement
 * 		 	apr�s que la mesure ait �t� effectu�e.
 *
 *
 * Par d�faut, les broches utilis�es sont celles de l'I2C1 : PB8 pour SCL et PB9 pour SDA.
 * Le basculement sur l'I2C2 (PB10 pour SCL et PB11 pour SDA) peut se faire en modifiant la fonction BH1750FI_init().
 * Il est possible de brancher 2 capteurs BH1750FVI sur le m�me I2C, pour ce faire l'un doit avoir sa broche ADDR reli�e
 * � la masse (son adresse sera alors 0x23), l'autre ayant sa broche ADDR aliment�e par une tension de 3,3V (son adresse
 * sera alors 0x5C).
 * Le capteur est aliment� sur sa broche Vcc en 3,3V.
 * @endverbatim
 */

#include "config.h"
#if USE_BH1750FVI
#include "stm32g4_uart.h"
#include "stm32g4_sys.h"
#include "stm32g4_bh1750fvi.h"
#include "stm32g4xx_hal.h"
#include "stm32g4_gpio.h"
#include "stm32g4_i2c.h"
#include "stdio.h"
//#include "stm32g4xx_nucleo.h"

//Si la pin ADDR n'est pas reli�e � la masse mais au 3.3V, changer cette macro en lui donnant la valeur BH1750FVI_ADDR_H
#define BH1750FVI_ADDR BH1750FVI_ADDR_L


/**
 * @brief	Exemple d'utilisation du capteur en mode one-shot, haute r�solution. Dans cet exemple,
 * 			toutes les 200ms, le capteur s'allume, prend une mesure, puis on lit la luminosit�
 * 			qu'on affiche ensuite sur l'uart. Le capteur s'�teint
 * 			automatiquement apr�s avoir effectu� une mesure.
 * @post	Attention, cette fonction de d�monstration est blocante !!!
 * @pre		La fonction printf �tant appel�e, il faut avoir initialis� au pr�alable une liaison s�rie.
 */
void BSP_BH1750FVI_demo()
{
	uint16_t luminosity;
	BSP_BH1750FVI_init();
	BSP_BH1750FVI_powerOn();
	BSP_BH1750FVI_measureMode(BH1750FVI_CON_L);
	while(1)
	{
		HAL_Delay(400);
		luminosity = BSP_BH1750FVI_readLuminosity();
		printf("\nLuminosite = %d lx", luminosity);
	}
}



/**
 * @brief	Fonction d'initialisation du bus I2C du capteur.
 */
void BSP_BH1750FVI_init()
{
	BSP_I2C_Init(BH1750FVI_I2C, STANDARD_MODE, true);
}

/**
 * @brief	Fonction d'allumage du capteur.
 */
void BSP_BH1750FVI_powerOn()
{
	BSP_I2C_WriteNoRegister(BH1750FVI_I2C, BH1750FVI_ADDR<<1, BH1750FVI_ON);
}

/**
 * @brief	Fonction d'extinction du capteur.
 */
void BSP_BH1750FVI_powerDown()
{
	BSP_I2C_WriteNoRegister(BH1750FVI_I2C, BH1750FVI_ADDR<<1, BH1750FVI_OFF);
}

/**
 * @brief	Fonction de reset du capteur.
 */
void BSP_BH1750FVI_reset()
{
	BSP_I2C_WriteNoRegister(BH1750FVI_I2C, BH1750FVI_ADDR<<1, BH1750FVI_RESET);
}

/**
 * @brief	Fonction permettant de lancer les/la mesure en choisissant un mode de mesure.
 * @param	mode: Mode de mesure souhait�. Le mode conseill� par le constructeur est le mode BH1750FVI_CON_H1
 * 			(ou BH1750FVI_OT_H1 pour une unique mesure), ce mode permettant d'avoir une sensibilit�	suffisante pour
 * 			mesurer la luminosit� dans l'obscurit�. Pour conna�tre les autres modes disponibles, voir le fichier bh1750fvi.h.
 */
void BSP_BH1750FVI_measureMode(uint8_t mode)
{
	BSP_I2C_WriteNoRegister(BH1750FVI_I2C, BH1750FVI_ADDR<<1, mode);
}


/**
 * @brief	Fonction permettant de lire la luminosit� mesur�e par le capteur.
 * @return	Cette fonction retourne la valeur de la luminosit� en lux.
 */
uint16_t BSP_BH1750FVI_readLuminosity()
{
	uint16_t luminositeNonConvertie = 0;
	uint32_t luminosite = 0;
	luminositeNonConvertie = BSP_BH1750FVI_read();
	luminosite = (((uint32_t)(luminositeNonConvertie))*53)/64; //La datasheet du capteur indique qu'il faut diviser par 1.2
	return (uint16_t)luminosite;
}

/**
 * @brief	Fonction permettant de lire un registre du capteur, typiquement les registres contenant les
 * 			mesures effectu�es par la capteur.
 * @return 	La valeur du registre (deux octets).
 */
uint16_t BSP_BH1750FVI_read()
{
	uint8_t ret[3] = {0xFF, 0xFF, 0xFF};
	BSP_I2C_ReadMultiNoRegister(BH1750FVI_I2C, BH1750FVI_ADDR<<1, ret, 3);
	return ret[1] | ((uint16_t)(ret[0])) << 8;
}

#endif

